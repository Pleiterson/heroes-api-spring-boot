package com.pleiterson.heroesapispringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeroesApiSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
